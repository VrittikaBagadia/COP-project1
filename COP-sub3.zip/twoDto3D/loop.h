#include "Edg3.h"
class Loop
{
	Edg3 econst[100];
	bool inloop;

	void inoutfind();
}
