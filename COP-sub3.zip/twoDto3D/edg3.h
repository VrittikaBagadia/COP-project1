//edg3.h
#include "Vert3.h"
class Edg3
{
	Vert3 s, e;
	bool hidden;
}