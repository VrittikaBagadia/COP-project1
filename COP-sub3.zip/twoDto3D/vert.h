//Vert.h
class Vert
{
	double x, y;
}