
//Vert3.h
class Vert3
{
	double x, y, z;
}