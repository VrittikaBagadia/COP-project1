//edg.h
#include "Vert.h"
class Edg
{
	Vert s, e;
	bool hidden;
}