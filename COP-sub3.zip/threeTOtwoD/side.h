class Side
{
	private:
		bool solid; ///<true if solid, false if hidden
		Point p1;	///<one end Point of the edge
		Point p2;	///<other end point of the edge
	public:
};