//Point.h
class Point
{
	private:
		double x,y;
	public:
};