//Edge.h
#include "Vertex.h"
class Edge
{
	private:
		Vertex v1,v2;
	public:
};