var searchData=
[
  ['vertex_5fto_5fpoint',['vertex_to_point',['../class_vertex.html#a55f3831f53c7150836532563ad30da1b',1,'Vertex']]]
];
