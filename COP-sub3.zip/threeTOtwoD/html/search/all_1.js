var searchData=
[
  ['distance_5ffrom_5fplane',['distance_from_plane',['../class_vertex.html#ab5d8d8a3015202cdbce749b57f4ef917',1,'Vertex']]]
];
