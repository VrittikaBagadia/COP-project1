var searchData=
[
  ['is_5fcutting',['is_cutting',['../class_plane.html#a973133b5a74cd37461ce6b46c1254664',1,'Plane']]]
];
