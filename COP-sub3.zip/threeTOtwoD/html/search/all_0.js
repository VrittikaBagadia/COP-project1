var searchData=
[
  ['create_5fmatrix',['create_matrix',['../class_plane.html#afb6253bcd033c87d25ca05e2a0174ac0',1,'Plane']]],
  ['create_5fnew_5fsolid',['create_new_solid',['../class_fig3d.html#aac9c6733233e2f8c21a50a4c30a2ed20',1,'Fig3d']]]
];
