var searchData=
[
  ['generate_5f2dpoints',['generate_2Dpoints',['../class_fig3d.html#a44d92006b733d19d899496657bca9729',1,'Fig3d']]],
  ['generate_5fsides',['generate_sides',['../class_fig3d.html#afef51436c82aae83ce95314e3ca36e06',1,'Fig3d']]]
];
