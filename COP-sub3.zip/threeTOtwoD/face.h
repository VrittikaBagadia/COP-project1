//Face.h
#include "Vertex.h"
class Face
{
	private:
		bool hole;
		Vertex vertices[12];
	public:
};