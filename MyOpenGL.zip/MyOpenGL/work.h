#ifndef WORK_H
#define WORK_H


class work
{
public:
    work();
};

#endif // WORK_H